import layers as my_layers
from torch.autograd import Variable
import numpy as np
import pytorch_utils as my_utils
import global_constants as gc
import torch
from torch import nn
import torch.nn.functional as F
from pos_encoding import position_encoding as PE, temporal_encoding as TE
import global_constants as gc


L1, L2 = ('l1', 'l2')
WEIGHT_TYINGS = ADJACENT, LAYER_WISE, _ = ('adjacent', 'layerwise', None)
GATE_TYINGS = GATE_GLOBAL, GATE_HOP_SPECIFIC = ('gate_global', 'gate_hop_specific')
def L2_pow2_func(x):
    #square the L2 distance
    return x **2

def L1_func(x):
    return torch.abs(x)

class MemoryModule(nn.Module):
    def __init__(self,
                 n_users, n_items, embedding_size,
                 item_seq_size, memory_size=None,
                 user_embeddings = None, item_embeddings = None,
                 W1 = None, W2 = None,
                 # output_item_embeddings = None, output_user_embeddings = None,
                 item_temporal_embedding = None,
                 use_temporal_encoding = False
                 ):
        super(MemoryModule, self).__init__()
        #define user memory, item memory and item output memory
        #each memory layer may have its own memory, or memory adjacent tying, or layer-wise tying
        # @inproceedings{sukhbaatar2015end,
        # title={End-to-end memory networks},
        # author={Sukhbaatar, Sainbayar and Weston, Jason and Fergus, Rob and others},
        #   booktitle={Advances in neural information processing systems},
        #   pages={2440--2448},
        #   year={2015}
        # }
        self._n_users, self._n_items, self._embedding_size = n_users, n_items, embedding_size
        self._memory_size, self._item_seq_size = memory_size, item_seq_size
        self._use_temporal_encoding = use_temporal_encoding
        #define user (A_u and item (A_i) memory embeddings, as well as output item embedding (C_i)
        self._user_embeddings = (
            user_embeddings or
            nn.Embedding(n_users, embedding_size, padding_idx=gc.PADDING_IDX) #can change this embedding for other initilizations
            # my_layers.ManualEmbedding(n_users, embedding_size, padding_idx=gc.PADDING_IDX)
        )
        self._item_embeddings = (
            item_embeddings or
            nn.Embedding(n_items, embedding_size, padding_idx=gc.PADDING_IDX)
            # my_layers.ManualEmbedding(n_users, embedding_size, padding_idx=gc.PADDING_IDX)
        )
        self._reset_weight()

        self._W1 = (
            W1 or
            nn.Linear(2*embedding_size, embedding_size) #combination of target user u and target item j
        )
        self._W2 = (
            W2 or
            nn.Linear(2*embedding_size, embedding_size) #combination of [u, j] with consumed item i
        )

        # self._C_i = (
        #     output_item_embeddings or
        #     nn.Embedding(n_items, embedding_size, padding_idx=gc.PADDING_IDX)
        # )
        #
        # self._C_u = (
        #     output_user_embeddings or
        #     nn.Embedding(n_users, embedding_size, padding_idx=gc.PADDING_IDX)
        # )
    def _reset_weight(self):
        self._user_embeddings.weight.data.normal_(0, 0.01)
        self._user_embeddings.weight.data[gc.PADDING_IDX].fill_(0)
        self._item_embeddings.weight.data.normal_(0, 0.01)
        self._item_embeddings.weight.data[gc.PADDING_IDX].fill_(0)

    def _embed_input(self, x):
        '''

        :param x: the input or item ids, which are the item ids the users consumed before.
        :return:
        '''
        return self._item_embeddings(x)

    def forward(self, x, u, j):
        '''

        :param x: input: consumed items, format: batch x consumed_item_ids
        :param u: current user. Format: batch x user_ids
        :param j: next item (target item)
        :return:
        '''
        if self.use_temporal_encoding:
            position_encoding = PE(
                self._embedding_size,
                self._item_seq_size
            )
            temporal_encoding = TE(self._memory_size, self._embedding_size)

            return (position_encoding * self._embed_input(x)).sum(2) + temporal_encoding
        else:
            return self._embed_input(x), self._user_embeddings(u), self._item_embeddings(j)



class OutputModule(nn.Module):


    def __init__(self, distance_type = L2, dropout_prob=0.5, non_linear = None):
        super(OutputModule, self).__init__()
        self._dist_func = L2_pow2_func if distance_type == L2 else L1_func
        self._dropout = nn.Dropout(p=dropout_prob)
        self._non_linear = non_linear

    def forward(self, weights, q_o, m_c, W2):
        '''

        :param weights: batch x num_consumed_items x embedding_size # batch x seq_len
        :param q_o: q_o = W1[u, j] #u: target user, j: target item # batch x embedding_size
        :param m_c: output embeddings of consumed items, batch x seq_len x embedding_size
        :param C: output memory
        :return:
        '''

        q_o = q_o.unsqueeze(1).expand_as(m_c) #batch x embedding_size --> batch x seq_len x embedding_size


        q_m = W2(torch.cat([m_c, q_o], dim=2))

        q_m = self._non_linear(q_m) if self._non_linear else q_m

        q_m = self._dropout(q_m)

        d2_q_m = -self._dist_func(q_m)
        weights_expand = weights.unsqueeze(2).expand_as(d2_q_m)
        dist_vec = torch.mul(d2_q_m, weights_expand)
        dist_vec_sum = dist_vec.sum(dim=1)# -sum{ alpha_k . DISTANCE( W2[ W1[u,j], i])    }
                                        # negative because the higher the distance, the lower the attention score.
                                        # dist_sum: batch x embedding_size, sum of the dist_vec_sum will return the total
                                        # distance from target item j to all consumed items of target user u.
        return dist_vec_sum

#
# class GeneralizationModule(nn.Module):
#
#     def __init__(self, distance_type = L2):
#         super(GeneralizationModule, self).__init__()
#         self._dist_func = L2_pow2_func if distance_type == L2 else L1_func
#
#
#
#     def forward(self, *input):
#         pass

class MaskedAttention(nn.Module):
    def __init__(self, distance_type=L2, dropout_prob=0.5, non_linear = None):
        super(MaskedAttention, self).__init__()
        self._dist_func = L2_pow2_func if distance_type==L2 else L1_func
        self._dropout = nn.Dropout(p=dropout_prob)
        self._non_linear = non_linear

    def forward(self, q, m, W2, mask):
        '''

        :param q: the query
        :param m: the memory
        :param A_memory: get the transformation weights in the A_memory
        :return: softmax(-DISTANCE(W2[m, q])) where q = W1[target_user, target_item] = W1[u, j]
        '''

        q = q.unsqueeze(1).expand_as(m)
        q_m = W2(torch.cat([m, q], dim=2)) # transformation between item memory and query
        q_m = self._non_linear(q_m) if self._non_linear else q_m
        q_m = self._dropout(q_m)


        d2_q_m = -self._dist_func(q_m) #negative because the higher the distance, the lower the attention score.
        d2_q_m = d2_q_m.sum(dim=2)  # measure the square distance of each input item to the target item, batch x seq_len

        # we want the padding index has very low scores
        d2_q_m = torch.mul(d2_q_m, mask)

        weights = F.softmax(d2_q_m, dim=1)
        # output = torch.mul(weights)
        return weights

class MemoryNetwork(nn.Module):

    def __init__(self,
                 n_users, n_items, embedding_size,
                 item_seq_size, memory_size = None,
                 weight_tying = LAYER_WISE,
                 # transform_tying = LAYER_WISE, #mean that all layers share same transformation, or None, means share nothing
                 n_hops=4,
                 distance_type = 'l1',
                 nonlinear_func = 'none',
                 dropout_prob = 0.5,
                 gate_tying = GATE_GLOBAL,
                 sum_mapping = False,
                 ret_sum = True
                 ):
        super(MemoryNetwork, self).__init__()
        assert weight_tying in WEIGHT_TYINGS, (
            'Available weight tying schemes are: {weight_tying_types}'
            .format(weight_tying_types=self.WEIGHT_TYINGS)
        )

        self._n_users, self._n_items, self._embedding_size = n_users, n_items, embedding_size
        self._item_seq_size, self._memory_size = item_seq_size, memory_size
        self._weight_tying = weight_tying
        self._n_hops = n_hops
        self._dropout_prob = dropout_prob
        self._ret_sum = ret_sum #return some at the end of forward or not

        if nonlinear_func == 'relu': self._non_linear = F.relu
        elif nonlinear_func == 'tanh': self._non_linear = F.tanh
        else: self._non_linear = None

        self._outputModule = OutputModule(distance_type=distance_type, dropout_prob=dropout_prob,
                                          non_linear=self._non_linear)

        self._attModule = MaskedAttention(distance_type=distance_type, dropout_prob=dropout_prob,
                                          non_linear=self._non_linear)



        # self._W1 = nn.Linear(2 * embedding_size, embedding_size)  # combination of target user u and target item j

        # self._W2 = nn.Linear(2 * embedding_size, embedding_size)  # combination of [u, j] with consumed item i

        self._sum_func = nn.Linear(embedding_size, 1) if sum_mapping else None

        #create memories:
        self.A_memories = nn.ModuleList() #input memory
        self.C_memories = nn.ModuleList() #output memory
        self._gate_transforms = nn.ModuleList() #gate transformation
        for i in range(n_hops):
            exist_prev = i > 0
            A_prev = self.A_memories[i-1] if exist_prev else None
            C_prev = self.A_memories[i-1] if exist_prev else None
            gate_prev_transform = self._gate_transforms[i-1] if exist_prev and gate_tying == GATE_GLOBAL else None

            if weight_tying == ADJACENT:
                A_user_embeddings = C_prev._user_embeddings if exist_prev else None
                A_item_embeddings  = C_prev._item_embeddings if exist_prev else None
                A_W1 = C_prev._W1 if exist_prev else None
                A_W2 = C_prev._W2 if exist_prev else None

                C_user_embeddings, C_item_embeddings = None, None
                C_W1, C_W2 = None, None

            elif weight_tying == LAYER_WISE:
                #same weights shared by all hops
                A_user_embeddings = A_prev._user_embeddings if exist_prev else None
                A_item_embeddings = A_prev._item_embeddings if exist_prev else None
                C_user_embeddings = C_prev._user_embeddings if exist_prev else None
                C_item_embeddings = C_prev._item_embeddings if exist_prev else None

                #same transformation shared by all hops
                A_W1 = A_prev._W1 if exist_prev else None
                A_W2 = A_prev._W2 if exist_prev else None
                C_W1 = C_prev._W1 if exist_prev else None
                C_W2 = C_prev._W2 if exist_prev else None

            else:
                A_user_embeddings, A_item_embeddings = None, None
                A_W1, A_W2 = None, None

                C_user_embeddings, C_item_embeddings = None, None
                C_W1, C_W2 = None, None

            self.A_memories.append(
                MemoryModule(
                    n_users, n_items, embedding_size,
                    item_seq_size, memory_size=None,
                    user_embeddings=A_user_embeddings, item_embeddings=A_item_embeddings,
                    W1 = A_W1, W2 = A_W2,
                    item_temporal_embedding=None,
                    use_temporal_encoding=False
                )
            )

            self.C_memories.append(
                MemoryModule(
                    n_users, n_items, embedding_size,
                    item_seq_size, memory_size=None,
                    user_embeddings=C_user_embeddings, item_embeddings=C_item_embeddings,
                    W1 = C_W1, W2 = C_W2,
                    item_temporal_embedding=None,
                    use_temporal_encoding=False
                )
            )

            gate_transform = gate_prev_transform if gate_prev_transform else \
                                   nn.Linear(embedding_size, embedding_size) #global gate transformation
            self._gate_transforms.append(gate_transform)


    def _make_query(self, u_embed, j_embed, W1):
        # transform target user u and target item j
        q = torch.cat([u_embed, j_embed], dim=1)
        q = self._non_linear(W1(q)) if self._non_linear else W1(q)
        return nn.Dropout(p=self._dropout_prob)(q)

    def _make_output_query(self, u_embed, j_embed, W2):
        # transform target user u and target item j
        q = torch.cat([u_embed, j_embed], dim=1)
        q = self._non_linear(W2(q)) if self._non_linear else W2(q)
        return nn.Dropout(p=self._dropout_prob)(q)


    # def _match_between_query_and_input_memory(self, u, m, A_memory):
    #     '''
    #     return the matching score between input memory
    #     :param u: query (combination of target user and target item)
    #     :param m:
    #     :return:
    #     '''
    #
    #     #u: batch x embedding_size
    #     #m: batch x seq_len x embedding_size
    #     u = u.unsqueeze(1).expand_as(m)
    #     u_m = A_memory._W2(torch.cat([m, u], dim=2))
    #     d2_u_m = -L2_pow2(u_m)
    #     d2_u_m = d2_u_m.sum(dim=2) #measure the square distance of each input item to the target item
    #     print d2_u_m
    #
    #     return F.softmax(d2_u_m, dim=1)



    def _make_mask(self, x):
        mask = np.asarray(my_utils.tensor2numpy(x.data.cpu().clone()), dtype=np.float64)
        # mask = my_utils.tensor2numpy(x != 0)
        mask[mask != gc.PADDING_IDX] = 1.0
        # mask[mask <= 0] = float('inf')
        mask[mask <= 0] = 65535

        return my_utils.gpu(Variable(my_utils.numpy2tensor(mask)).type(torch.FloatTensor), use_cuda=my_utils.is_cuda(x))


    def _get_l2_loss(self):
        #get user and item output embedding L2 loss
        # using l1, then uncomment below
        # user_target = Variable(torch.from_numpy(np.zeros((self._n_users, self._embedding_size)))).type(torch.FloatTensor)
        # item_target = Variable(torch.from_numpy(np.zeros((self._n_items, self._embedding_size)))).type(torch.FloatTensor)


        # item_reg = F.l1_loss(self.C_memories[-1]._item_embeddings.weight,
        #                      target=item_target,
        #                      reduction='sum')
        # user_reg = F.l1_loss(self.C_memories[-1]._user_embeddings.weight,
        #                      target=user_target,
        #                      reduction='sum')

        item_reg_l2 = torch.norm(self.C_memories[-1]._item_embeddings.weight)
        user_reg_l2 = torch.norm(self.C_memories[-1]._user_embeddings.weight)
        # return item_reg + user_reg
        return item_reg_l2 + user_reg_l2


    def forward(self, x, u, j):
        """

        :param x: the consumed items of user u, format: batch_size x 1 x n_items
        :param u: user, format batch_size x 1
        :param j: next item, format: batch_size x 1
        :return:
        """
        mask = self._make_mask(x)

        o = None #output
        hops_output = []
        for i, (A, C) in enumerate(zip(self.A_memories, self.C_memories)):

            prev_o = i > 0

            #get user embedding:
            a_u = A._user_embeddings(u) # batch x embedding_size
            # print 'MemNet: max item value:',torch.max(j)
            a_j = A._item_embeddings(j) # batch x embedding_size
            m_a = A._item_embeddings(x)  # get the item embeddings in input memory, return batch x seq_len x embedding_size

            #make query
            # W1 = self._W1
            W1 = A._W1
            q_a = self._make_query(a_u, a_j, W1) #batch x embedding_size

            if prev_o:
                gated = torch.sigmoid(self._gate_transforms[i](o))
                q_a = torch.mul((1-gated), q_a) + torch.mul(gated, o) #residual connection.

            # W2 = self._W2
            W2 = A._W2
            weights = self._attModule(q_a, m_a, W2, mask)

            c_j = C._item_embeddings(j)
            c_u = C._user_embeddings(u)
            m_c = C._item_embeddings(x)

            # W1_output = self._W1
            W1_output = C._W1
            q_o = self._make_output_query(c_u, c_j, W1_output) #output combination of target user u and target item j

            # W2_output = self._W2
            W2_output = C._W2
            o = self._outputModule(weights, q_o, m_c, W2_output)

            hops_output.append((o, weights))
        # print hops_output[-1][0].sum(dim=1)
        if self._ret_sum:
            if self._sum_func:
                return self._sum_func(hops_output[-1][0])
            else:
                return hops_output[-1][0].sum(dim=1)  # return output of the last hop.
            # return torch.sigmoid(self.sum_func(hops_output[-1][0])) #return output of the last hop.
        else:
            return hops_output[-1][0]



class GMMF(nn.Module):
    '''
    generalized metric matrix factorization method
    '''
    def __init__(self, n_users, n_items, embedding_size=16, distance_type = 'l1', sum_mapping = False, ret_sum = True):
        super(GMMF, self).__init__()
        self._n_users = n_users
        self._n_items = n_items
        self._n_factors = embedding_size
        self._embedding_size = embedding_size
        self._ret_sum = ret_sum


        self._user_embeddings = nn.Embedding(n_users, embedding_size)


        self._item_embeddings = nn.Embedding(n_items, embedding_size)

        self._fc1 = nn.Linear(2*embedding_size, embedding_size, bias=True)

        self._dist_func = L2_pow2_func if distance_type == L2 else L1_func

        self._sum_func = nn.Linear(embedding_size, 1) if sum_mapping else None

        self._reset_weights()

    def _reset_weights(self):
        self._user_embeddings.weight.data.normal_(0, 1.0 / self._embedding_size)
        self._user_embeddings.weight.data[gc.PADDING_IDX].fill_(0)
        self._item_embeddings.weight.data.normal_(0, 1.0 / self._embedding_size)
        self._item_embeddings.weight.data[gc.PADDING_IDX].fill_(0)

    def _get_l2_loss(self):
        #get user and item output embedding L2 loss
        # using l1, then uncomment below
        # user_target = Variable(torch.from_numpy(np.zeros((self._n_users, self._embedding_size)))).type(torch.FloatTensor)
        # item_target = Variable(torch.from_numpy(np.zeros((self._n_items, self._embedding_size)))).type(torch.FloatTensor)


        # item_reg = F.l1_loss(self.C_memories[-1]._item_embeddings.weight,
        #                      target=item_target,
        #                      reduction='sum')
        # user_reg = F.l1_loss(self.C_memories[-1]._user_embeddings.weight,
        #                      target=user_target,
        #                      reduction='sum')

        item_reg_l2 = torch.norm(self._item_embeddings.weight)
        user_reg_l2 = torch.norm(self._user_embeddings.weight)
        # return item_reg + user_reg
        return item_reg_l2 + user_reg_l2

    def forward(self, x=None, uids = None, iids = None):
        user_embeds = self._user_embeddings(uids)  # first dimension is batch size
        item_embeds = self._item_embeddings(iids)

        user_embeds = my_utils.flatten(user_embeds)
        item_embeds = my_utils.flatten(item_embeds)
        v = torch.cat([user_embeds, item_embeds], dim=1)  # dim = 0 is the batch_size

        v = self._fc1(v)
        v = self._dist_func(v)
        if self._ret_sum:
            v = self._sum_func(v) if self._sum_func else v.sum(dim=1)
            # v = torch.sum(v, dim=1)
            # v = torch.sqrt(v)
            return -v
        else:
            return -v



class CombinedModel(nn.Module):
    def __init__(self,
                 n_users, n_items, embedding_size,
                 item_seq_size, memory_size = None,
                 weight_tying = LAYER_WISE,
                 # transform_tying = LAYER_WISE, #mean that all layers share same transformation, or None, means share nothing
                 n_hops=4,
                 distance_type = 'l1',
                 nonlinear_func = 'none',
                 dropout_prob = 0.5,
                 gate_tying = GATE_GLOBAL):
        super(CombinedModel, self).__init__()
        self._memnet = MemoryNetwork(n_users=n_users, n_items=n_items, embedding_size=embedding_size,
                               item_seq_size=item_seq_size, memory_size = memory_size, weight_tying=weight_tying,
                               n_hops=n_hops, distance_type=distance_type, nonlinear_func=nonlinear_func,
                               dropout_prob=dropout_prob, gate_tying=gate_tying, ret_sum = True)
        self._gmmf = GMMF(n_users=n_users, n_items=n_items, embedding_size=embedding_size, ret_sum=True)

        #self._fc = nn.Linear(2, 1) #combine two distances
        self._fc = nn.Linear(2*embedding_size, 1) #combine two distances

        #for concat attention
        self._Wa = nn.Linear(2,2)
        self._Va = nn.Linear(2,2)
        self._dropout = nn.Dropout(p=0.5)

    def _get_l2_loss(self):
        return self._memnet._get_l2_loss() + self._gmmf._get_l2_loss()

    def _attention(self, dist):
        scores = self._Va(F.tanh(self._dropout(self._Wa(dist))))
        weights = F.softmax(scores, dim=1)
        return torch.mul(weights, dist)

    def forward(self,  x, u, j):
        dist1 = self._memnet(x, u, j) #distance between target item j and prev consumed items x
        dist2 = self._gmmf(x=None, uids=u, iids=j) #direct distance between target item j and user u
        dist1 = dist1.view(-1, 1)
        dist2 = dist2.view(-1, 1)

        # dist = torch.cat([dist1, dist2], dim=1) #batch x 2
        #dist = self._attention(dist)
        #return dist.sum(dim=1)
        
        #return self._fc(dist) #simply combine them, need to add attention score.
        
        return dist1 + dist2










