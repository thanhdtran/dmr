"""
Loss functions for recommender models.

The pointwise, BPR, and hinge losses are a good fit for
implicit feedback models trained through negative sampling.

The regression and Poisson losses are used for explicit feedback
models.
"""

import torch
from torch.autograd import Variable
import torch.nn.functional as F
import numpy as np

def single_pointwise_bceloss(positive_predictions, mask=None, average=False):
    positive_labels = np.ones(positive_predictions.size()).flatten()
    is_cuda = positive_predictions.is_cuda
    if is_cuda:
        positive_labels = Variable(torch.from_numpy(positive_labels)).type(torch.FloatTensor).cuda()  # fix expected FloatTensor but got LongTensor
    else:
        positive_labels = Variable(torch.from_numpy(positive_labels)).type(torch.FloatTensor)  #fix expected FloatTensor but got LongTensor
    positive_predictions = F.sigmoid(positive_predictions)
    positive_loss = F.binary_cross_entropy(positive_predictions, positive_labels)
    loss = positive_loss
    if mask is not None:
        mask = mask.float()
        loss = loss * mask
        return loss.sum() / mask.sum()
    if average:
        return loss.mean()
    else:
        return loss.sum()


def pointwise_bceloss(positive_predictions, negative_predictions, mask=None, average=False):
    positive_labels = np.ones(positive_predictions.size()).flatten()
    negative_labels = np.zeros(negative_predictions.size()).flatten()

    is_cuda = positive_predictions.is_cuda
    if is_cuda:
        positive_labels = Variable(torch.from_numpy(positive_labels)).type(torch.FloatTensor).cuda()  # fix expected FloatTensor but got LongTensor
        negative_labels = Variable(torch.from_numpy(negative_labels)).type(torch.FloatTensor).cuda()  # fix expected FloatTensor but got LongTensor
    else:
        positive_labels = Variable(torch.from_numpy(positive_labels)).type(torch.FloatTensor)  #fix expected FloatTensor but got LongTensor
        negative_labels = Variable(torch.from_numpy(negative_labels)).type(torch.FloatTensor)  #fix expected FloatTensor but got LongTensor

    positive_predictions = F.sigmoid(positive_predictions)
    negative_predictions = F.sigmoid(negative_predictions)

    positive_loss = F.binary_cross_entropy(positive_predictions, positive_labels)
    negative_loss = F.binary_cross_entropy(negative_predictions, negative_labels)
    loss = positive_loss + negative_loss
    if mask is not None:
        mask = mask.float()
        loss = loss * mask
        return loss.sum() / mask.sum()
    if average:
        return loss.mean()
    else:
        return loss.sum()
def pointwise_loss(positive_predictions, negative_predictions, mask=None, average=False):
    """
    Logistic loss function.

    Parameters
    ----------

    positive_predictions: tensor
        Tensor containing predictions for known positive items.
    negative_predictions: tensor
        Tensor containing predictions for sampled negative items.
    mask: tensor, optional
        A binary tensor used to zero the loss from some entries
        of the loss tensor.

    Returns
    -------

    loss, float
        The mean value of the loss function.
    """

    #old version, without using log loss,
    # positives_loss = (1.0 - F.sigmoid(positive_predictions))
    # negatives_loss = F.sigmoid(negative_predictions)

    #my new version, similar to bce, log loss is better because it is a monoto function
    positives_loss = -torch.log(F.sigmoid(positive_predictions))
    negatives_loss = -torch.log(1.0 - F.sigmoid(negative_predictions))

    loss = (positives_loss + negatives_loss)

    if mask is not None:
        mask = mask.float()
        loss = loss * mask
        return loss.sum() / mask.sum()

    if average:
        return loss.mean()
    else: return loss.sum()


def bpr_loss(positive_predictions, negative_predictions, mask=None, average=False):
    """
    Bayesian Personalised Ranking [1]_ pairwise loss function.

    Parameters
    ----------

    positive_predictions: tensor
        Tensor containing predictions for known positive items.
    negative_predictions: tensor
        Tensor containing predictions for sampled negative items.
    mask: tensor, optional
        A binary tensor used to zero the loss from some entries
        of the loss tensor.

    Returns
    -------

    loss, float
        The mean value of the loss function.

    References
    ----------

    .. [1] Rendle, Steffen, et al. "BPR: Bayesian personalized ranking from
       implicit feedback." Proceedings of the twenty-fifth conference on
       uncertainty in artificial intelligence. AUAI Press, 2009.
    """

    #old version, which didn't use log loss.
    # loss = (1.0 - F.sigmoid(positive_predictions -
    #                         negative_predictions))

    #my version, using log loss
    loss = - torch.log(torch.sigmoid
                                 (-negative_predictions + positive_predictions)
                        )



    if mask is not None:
        mask = mask.float()
        loss = loss * mask
        return loss.sum() / mask.sum()

    if average:
        return loss.mean()
    else:
        return loss.sum()


def hinge_loss(positive_predictions, negative_predictions, mask=None, average=False):
    """
    Hinge pairwise loss function.

    Parameters
    ----------

    positive_predictions: tensor
        Tensor containing predictions for known positive items.
    negative_predictions: tensor
        Tensor containing predictions for sampled negative items.
    mask: tensor, optional
        A binary tensor used to zero the loss from some entries
        of the loss tensor.

    Returns
    -------

    loss, float
        The mean value of the loss function.
    """

    loss = torch.clamp(negative_predictions -
                       positive_predictions +
                       1.0, 0.0)

    #my version, adding log loss:
    # loss = -torch.log(1-F.sigmoid(loss))

    if mask is not None:
        mask = mask.float()
        loss = loss * mask
        return loss.sum() / mask.sum()

    if average:
        return loss.mean()
    else:
        return loss.sum()


def adaptive_hinge_loss(positive_predictions, negative_predictions, mask=None, average=False):
    """
    Adaptive hinge pairwise loss function. Takes a set of predictions
    for implicitly negative items, and selects those that are highest,
    thus sampling those negatives that are closes to violating the
    ranking implicit in the pattern of user interactions.

    Approximates the idea of weighted approximate-rank pairwise loss
    introduced in [2]_

    Parameters
    ----------

    positive_predictions: tensor
        Tensor containing predictions for known positive items.
    negative_predictions: tensor
        Iterable of tensors containing predictions for sampled negative items.
        More tensors increase the likelihood of finding ranking-violating
        pairs, but risk overfitting.
    mask: tensor, optional
        A binary tensor used to zero the loss from some entries
        of the loss tensor.

    Returns
    -------

    loss, float
        The mean value of the loss function.

    References
    ----------

    .. [2] Weston, Jason, Samy Bengio, and Nicolas Usunier. "Wsabie:
       Scaling up to large vocabulary image annotation." IJCAI.
       Vol. 11. 2011.
    """

    highest_negative_predictions, _ = torch.max(negative_predictions, 0)

    return hinge_loss(positive_predictions, highest_negative_predictions.squeeze(), mask=mask, average=average)
    # return bpr_loss(positive_predictions, highest_negative_predictions, mask=mask)

    # return WARPLoss()
def regression_loss(observed_ratings, predicted_ratings, average=False):
    """
    Regression loss.

    Parameters
    ----------

    observed_ratings: tensor
        Tensor containing observed ratings.
    predicted_ratings: tensor
        Tensor containing rating predictions.

    Returns
    -------

    loss, float
        The mean value of the loss function.
    """

    # assert_no_grad(observed_ratings)
    if average:
        return ((observed_ratings - predicted_ratings) ** 2).mean()
    else:
        return ((observed_ratings - predicted_ratings) ** 2).sum()


def poisson_loss(observed_ratings, predicted_ratings, average=False):
    """
    Poisson loss.

    Parameters
    ----------

    observed_ratings: tensor
        Tensor containing observed ratings.
    predicted_ratings: tensor
        Tensor containing rating predictions.

    Returns
    -------

    loss, float
        The mean value of the loss function.
    """

    # assert_no_grad(observed_ratings)
    if average:
        return (predicted_ratings - observed_ratings * torch.log(predicted_ratings)).mean()
    else:
        return (predicted_ratings - observed_ratings * torch.log(predicted_ratings)).sum()


def logistic_loss(observed_ratings, predicted_ratings, average=False):
    """
    Logistic loss for explicit data.

    Parameters
    ----------

    observed_ratings: tensor
        Tensor containing observed ratings which
        should be +1 or -1 for this loss function.
    predicted_ratings: tensor
        Tensor containing rating predictions.

    Returns
    -------

    loss, float
        The mean value of the loss function.
    """

    # assert_no_grad(observed_ratings)

    # Convert target classes from (-1, 1) to (0, 1)
    observed_ratings = torch.clamp(observed_ratings, 0, 1)

    return F.binary_cross_entropy_with_logits(predicted_ratings,
                                              observed_ratings,
                                              size_average=average)
