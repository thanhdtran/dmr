"""
Module containing functions for negative item sampling.
"""

import numpy as np
from scipy.sparse import csr_matrix
import global_constants as gc
np.random.seed(gc.SEED)

class Sampler(object):
    def __init__(self):
        super(Sampler, self).__init__()
        self.user_neg_items_map = dict()

    def init_user_item_seqs(self, user_all_items, num_users, num_items):
        all_items = range(0, gc.PADDING_IDX) + range(gc.PADDING_IDX + 1, num_items)
        all_items = set(all_items)
        for uid in range(num_users):
            if uid == gc.PADDING_IDX: continue
            neg_items = all_items - set(user_all_items[uid])
            self.user_neg_items_map[uid] = list(neg_items)


    def set_interactions(self, interactions):
        csr_data = interactions.tocsr()
        self.build_neg_dict(csr_data)

    def build_neg_dict(self, csr_data):
        #for each user, store the unobserved values into a dict for sampling later.
        csr_data = csr_matrix(csr_data)
        n_users, n_items = csr_data.shape
        user_counts = np.zeros(n_users)
        for u in range(n_users): user_counts = csr_data[u].getnnz()
        pass


    def random_sample_items(self, num_items, shape, user_ids = None, random_state=None):
        """
        Randomly sample a number of items.

        Parameters
        ----------

        num_items: int
            Total number of items from which we should sample:
            the maximum value of a sampled item id will be smaller
            than this.
        shape: int or tuple of ints
            Shape of the sampled array.
        random_state: np.random.RandomState instance, optional
            Random state to use for sampling.
            shape: (number of users, number of items)

        Returns
        -------

        items: np.array of shape [shape]
            Sampled item ids.
        """
        if user_ids is not None:
            items = np.zeros(shape, dtype=np.int64)
            num_neg_item_per_user = 1
            if isinstance(shape, tuple):
                num_neg_item_per_user = shape[-1]
            else:
                for i, uid in enumerate(user_ids):
                    # neg_items = set(range(num_items)) - set(self.user_seqs_nopad[uid])
                    items[i] = np.random.choice(self.user_neg_items_map[uid], num_neg_item_per_user,replace=False)
            return items
        else:
            if random_state is None:
                random_state = np.random.RandomState()

            items = random_state.randint(1, num_items, shape, dtype=np.int64) #random from 1 to num_items as 0 is PADDING_IDX

            return items
