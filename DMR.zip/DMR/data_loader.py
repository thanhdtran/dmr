'''
A general data loader, to load different kinds of data, as long as the format is:
user_id \t item_id \t rating.
'''
import numpy as np
import pandas as pd
import scipy.sparse as sp
import global_constants as gc
from joblib import Parallel, delayed
import multiprocessing

# np.random.seed(123456)
def _sliding_window(tensor, window_size, step_size=1):

    for i in range(len(tensor), 0, -step_size):
        yield tensor[max(i - window_size, 0):i]


def _generate_sequences(user_ids, item_ids,
                        indices,
                        max_sequence_length,
                        step_size):

    for i in range(len(indices)):

        start_idx = indices[i]

        if i >= len(indices) - 1:
            stop_idx = None
        else:
            stop_idx = indices[i + 1]

        for seq in _sliding_window(item_ids[start_idx:stop_idx],
                                   max_sequence_length,
                                   step_size):

            yield (user_ids[i], seq)

def load_data(path, sep = '\t', header=None, dataset=None):
    data = pd.read_csv(path, sep=sep, header=header)
    user_ids = np.asarray(data[0])
    item_ids = np.asarray(data[1])
    ratings = None
    # ratings = data[2] #we don't need it because of implicit feedback dataset.
    timestamps = None
    if data.shape[1] >= 4:
        #contain timestamp
        timestamps = data[3]
    return Interactions(user_ids, item_ids, ratings, timestamps, dataset=dataset)


class Interactions(object):
    """
    Interactions object. Contains (at a minimum) pair of user-item
    interactions, but can also be enriched with ratings, timestamps,
    and interaction weights.

    For *implicit feedback* scenarios, user ids and item ids should
    only be provided for user-item pairs where an interaction was
    observed. All pairs that are not provided are treated as missing
    observations, and often interpreted as (implicit) negative
    signals.

    For *explicit feedback* scenarios, user ids, item ids, and
    ratings should be provided for all user-item-rating triplets
    that were observed in the dataset.

    Parameters
    ----------

    user_ids: array of np.int32
        array of user ids of the user-item pairs
    item_ids: array of np.int32
        array of item ids of the user-item pairs
    ratings: array of np.float32, optional
        array of ratings
    timestamps: array of np.int32, optional
        array of timestamps
    weights: array of np.float32, optional
        array of weights
    num_users: int, optional
        Number of distinct users in the dataset.
        Must be larger than the maximum user id
        in user_ids.
    num_items: int, optional
        Number of distinct items in the dataset.
        Must be larger than the maximum item id
        in item_ids.

    Attributes
    ----------

    user_ids: array of np.int32
        array of user ids of the user-item pairs
    item_ids: array of np.int32
        array of item ids of the user-item pairs
    ratings: array of np.float32, optional
        array of ratings
    timestamps: array of np.int32, optional
        array of timestamps
    weights: array of np.float32, optional
        array of weights
    num_users: int, optional
        Number of distinct users in the dataset.
    num_items: int, optional
        Number of distinct items in the dataset.
    """

    def __init__(self, user_ids, item_ids,
                 ratings=None,
                 timestamps=None,
                 weights=None,
                 num_users=None,
                 num_items=None,
                 dataset='ml1m'
                 ):

        self.num_users = num_users or int(user_ids.max() + 1)
        self.num_items = num_items or int(item_ids.max() + 1)

        self.user_ids = user_ids
        self.item_ids = item_ids
        self.ratings = ratings
        self.timestamps = timestamps
        self.weights = weights

        self._user_seqs = dict() #mapping each user id to the user's sequence.
        self._item_seqs = dict() #mapping each item id to the item's sequence.
        self._max_len_user_seq = 0
        self._max_len_item_seq = 0

        self._dataset = dataset

        self._check()
        self.to_sequence()
        self.to_sequence_no_padding()

        #using word2vec model to shorten user and item sequence length
        self.interactions_dict = dict()
        self._max_cached_interactions = 5000000 #5 millions for caching
        self._user_wv_model = None
        self._item_wv_model = None

    def _set_user_item_wv_model(self, user_wv_model, item_wv_model):
        self._user_wv_model = user_wv_model
        self._item_wv_model = item_wv_model

    def __repr__(self):

        return ('<Interactions dataset ({num_users} users x {num_items} items '
                'x {num_interactions} interactions)>'
                .format(
                    num_users=self.num_users,
                    num_items=self.num_items,
                    num_interactions=len(self)
                ))

    def __len__(self):

        return len(self.user_ids)

    def _check(self):

        if self.user_ids.max() >= self.num_users:
            raise ValueError('Maximum user id greater '
                             'than declared number of users.')
        if self.item_ids.max() >= self.num_items:
            raise ValueError('Maximum item id greater '
                             'than declared number of items.')

        num_interactions = len(self.user_ids)

        for name, value in (('item IDs', self.item_ids),
                            ('ratings', self.ratings),
                            ('timestamps', self.timestamps),
                            ('weights', self.weights)):

            if value is None:
                continue

            if len(value) != num_interactions:
                raise ValueError('Invalid {} dimensions: length '
                                 'must be equal to number of interactions'
                                 .format(name))

    def tocoo(self):
        """
        Transform to a scipy.sparse COO matrix.
        """

        row = self.user_ids
        col = self.item_ids
        data = self.ratings if self.ratings is not None else np.ones(len(self))

        return sp.coo_matrix((data, (row, col)),
                             shape=(self.num_users, self.num_items))

    def tocsr(self):
        """
        Transform to a scipy.sparse CSR matrix.
        """

        return self.tocoo().tocsr()


    def to_sequence_no_padding(self):
        if self.timestamps is None:
            raise ValueError('Cannot convert to sequences, '
                             'timestamps not available.')

        if 0 in self.item_ids:
            self.item_ids = np.asarray(self.item_ids)
            self.item_ids += 1 #shifted one more position
            self.num_items += 1 #adding one more token, leave index 0 as for padding
        if 0 in self.user_ids:
            self.user_ids = np.asarray(self.user_ids)
            self.user_ids += 1 #shifted one more position
            self.num_users += 1  # adding one more token, leave index 0 as for padding
        if 0 in self.item_ids or 0 in self.user_ids:
            raise ValueError('0 is used as an item id, conflicting '
                             'with the sequence padding value.')
        #extract all sequences
        user_seqs, item_seqs = self._extract_seqs(do_padding=False)


        self.user_seqs_nopad = [user_seqs[uid] for uid in self.user_ids]
        self.item_seqs_nopad = [item_seqs[iid] for iid in self.item_ids]


        # res = Parallel(n_jobs=8)(delayed(self._extract_topn_in_seq(uid, iid, user_seqs[uid], item_seqs[iid], topn))
        #                          for uid, iid in zip(self.user_ids, self.item_ids))
        # for (uid, iid, user_seq, item_seq) in res:
        #     self.interactions_dict[(uid, iid)] = (user_seq, item_seq)

        # for i, uid in enumerate(self.user_ids):
        #     iid = self.item_ids[i]
        #     user_seq = user_seqs[uid]  # contain all items he consumed.
        #     item_seq = item_seqs[iid]  # contain all users consumed the item
        #
        #     user_seq_tmp = np.zeros(topn)
        #     item_seq_tmp = np.zeros(topn)
        #
        #     user_seq = self.item_model.get_similar_words_in_seq(iid, user_seq, topn=topn)
        #     item_seq = self.user_model.get_similar_words_in_seq(uid, item_seq, topn=topn)
        #
        #     user_seq_tmp = user_seq[:topn]
        #     item_seq_tmp = item_seq[:topn]
        #     user_seq = user_seq_tmp
        #     item_seq = item_seq_tmp
        #
        #     self.interactions_dict[(uid, iid)] = (user_seq, item_seq)


    def save_topn_seqs(self, res, check=True):
        # self.interactions_dict = dict()
        for uid, iid, user_seq, item_seq in res:
            origin_user_len = len(user_seq)
            origin_item_len = len(item_seq)

            user_seq = user_seq[user_seq != iid]
            item_seq = item_seq[item_seq != uid]
            if check:
                if len(user_seq) < origin_user_len:
                    #removed iid
                    tmp = np.zeros(origin_user_len, dtype=np.int64)
                    tmp[-len(user_seq):] = user_seq #pad 0
                    user_seq = tmp
                if len(item_seq) < origin_item_len:
                    #removed iid
                    tmp = np.zeros(origin_item_len, dtype=np.int64)
                    tmp[-len(item_seq):] = item_seq #pad 0
                    item_seq = tmp
            self.interactions_dict[(uid, iid)] = (np.asarray(user_seq, dtype=np.int64), np.asarray(item_seq, dtype=np.int64))


    def _extract_seqs(self, do_padding = True):
        '''
        extract sequences with/without padding
        :param type: user/item
        :return:
        '''
        user_seqs = dict()
        item_seqs = dict()


        sort_indices = np.lexsort((self.timestamps,
                                   self.user_ids))

        user_ids = self.user_ids[sort_indices]
        item_ids = self.item_ids[sort_indices]

        user_unique_ids, indices, counts = np.unique(user_ids,
                                                     return_index=True,
                                                     return_counts=True)
        # get user sequences in here:
        for i in range(len(indices)):
            start = indices[i]
            if i == (len(indices) - 1):
                end = len(user_ids)
            else:
                end = indices[i + 1]

            uid = user_unique_ids[i]
            tmp_seq = item_ids[start:end]

            ############for debugging:
            # tmp_seq = tmp_seq[:50]
            ##########################
            if do_padding:
                uid_seq = np.zeros(self._max_len_user_seq, dtype=np.int64)
                uid_seq[-len(tmp_seq):] = tmp_seq
            else:
                uid_seq = tmp_seq
            user_seqs[uid] = uid_seq



        sort_indices = np.lexsort((self.timestamps,
                                   self.item_ids))

        user_ids = self.user_ids[sort_indices]
        item_ids = self.item_ids[sort_indices]

        item_unique_ids, indices, counts = np.unique(item_ids,
                                                     return_index=True,
                                                     return_counts=True)

        # get item sequences in here:
        for i in range(len(indices)):
            start = indices[i]
            if i == (len(indices) - 1):
                end = len(item_ids)
            else:
                end = indices[i + 1]

            iid = item_unique_ids[i]

            tmp_seq = user_ids[start:end]

            if do_padding:
                iid_seq = np.zeros(self._max_len_item_seq, dtype=np.int64)
                iid_seq[-len(tmp_seq):] = tmp_seq
            else:
                iid_seq = tmp_seq

            # store to a dict:
            item_seqs[iid] = iid_seq

        return user_seqs, item_seqs
    def to_sequence(self, same_length = True):
        '''
        extract user and item sequences then store to a dict for querring later.
        the user sequence's length is the max length of all user sequences.
        the item sequence's length is the max length of all item sequences.
        All the sequences are padded by 0.
        :param same_length: if this is set to true, then maximum sequence length will be applied for both user, seq
        otherwise, sequence length of users and items can be different
        :return:
        '''

        if self.timestamps is None:
            raise ValueError('Cannot convert to sequences, '
                             'timestamps not available.')

        if 0 in self.item_ids:
            self.item_ids = np.asarray(self.item_ids)
            self.item_ids += 1 #shifted one more position
            self.num_items += 1 #adding one more token, leave index 0 as for padding
        if 0 in self.user_ids:
            self.user_ids = np.asarray(self.user_ids)
            self.user_ids += 1 #shifted one more position
            self.num_users += 1  # adding one more token, leave index 0 as for padding
        if 0 in self.item_ids or 0 in self.user_ids:
            raise ValueError('0 is used as an item id, conflicting '
                             'with the sequence padding value.')



        user_ids = self.user_ids
        item_ids = self.item_ids
        _, user_counts = np.unique(user_ids, return_index=False, return_counts=True)
        _, item_counts = np.unique(item_ids, return_index=False, return_counts=True)
        if same_length:
            self._max_len_user_seq = max(max(user_counts), max(item_counts))

            self._max_len_item_seq = self._max_len_user_seq
        else:
            self._max_len_user_seq = max(user_counts)
            self._max_len_item_seq = max(item_counts)

        ############for debugging:
        # self._max_len_user_seq = 50
        # self._max_len_item_seq = 50
        ###########################


        ############ GENERATE user sequence#############################
        # Sort first by user id, then by timestamp
        sort_indices = np.lexsort((self.timestamps,
                                   self.user_ids))

        user_ids = self.user_ids[sort_indices]
        item_ids = self.item_ids[sort_indices]

        user_unique_ids, indices, counts = np.unique(user_ids,
                                              return_index=True,
                                              return_counts=True)


        #get user sequences in here:

        for i in range(len(indices)):
            start = indices[i]
            if i == (len(indices) - 1):
                end = len(user_ids)
            else: end = indices[i+1]

            uid = user_unique_ids[i]
            tmp_seq = item_ids[start:end]

            ############for debugging:
            # tmp_seq = tmp_seq[:50]
            ##########################

            uid_seq = np.zeros(self._max_len_user_seq, dtype=np.int64)
            uid_seq[-len(tmp_seq):] = tmp_seq
            self._user_seqs[uid] = uid_seq #store to a dictionary for querring later

        #################################################################

        ############ GENERATE item sequence#############################
        # Sort first by item id, then by timestamp
        sort_indices = np.lexsort((self.timestamps,
                                   self.item_ids))

        user_ids = self.user_ids[sort_indices]
        item_ids = self.item_ids[sort_indices]

        item_unique_ids, indices, counts = np.unique(item_ids,
                                                     return_index=True,
                                                     return_counts=True)

        # get item sequences in here:
        for i in range(len(indices)):
            start = indices[i]
            if i == (len(indices) - 1):
                end = len(item_ids)
            else:
                end = indices[i + 1]

            iid = item_unique_ids[i]

            tmp_seq = user_ids[start:end]

            ############for debugging:
            # tmp_seq = tmp_seq[:50]
            ##########################

            iid_seq = np.zeros(self._max_len_item_seq, dtype=np.int64)
            iid_seq[-len(tmp_seq):] = tmp_seq

            # store to a dict:
            self._item_seqs[iid] = iid_seq
        #################################################################

        #there may happen that some items don't have any users or some users don't have any times --> adding empty vector
        for uid in range(self.num_users):
            if uid == gc.PADDING_IDX: continue
            if uid not in self._user_seqs:
                self._user_seqs[uid] = np.zeros(self._max_len_user_seq, dtype=np.int64)

        for iid in range(self.num_items):
            if iid == gc.PADDING_IDX: continue
            if iid not in self._item_seqs:
                self._item_seqs[iid] = np.zeros(self._max_len_item_seq, dtype=np.int64)

    def get_all_item_seqs(self):
        res = []
        for seq in self._item_seqs.values():
            res.append(seq)
        return res

    def get_all_user_seqs(self):
        res = []
        for seq in self._user_seqs.values():
            res.append(seq)
        return res

    def get_all_user_seqs_nopad(self):
        return self.user_seqs_nopad

    def get_all_item_seqs_nopad(self):
        return self.item_seqs_nopad

    def get_user_seq(self, user_id, item_id=-1):
        '''
        get one user sequence given a user_id
        :param user_id:
        :param item_id: to ignore the item_id in the sequence.
        :return:
        '''
        if item_id == -1:
            if user_id in self._user_seqs:
                return self._user_seqs[user_id]
            else:
                return np.zeros(self._max_len_user_seq, dtype=np.int64)
        else:
            return self.interactions_dict[(user_id, item_id)][0]

    def get_batch_user_seqs(self, user_ids):
        '''
        get batch user sequences
        :param user_ids:
        :return:
        '''
        res = np.zeros(shape=(len(user_ids), self._max_len_user_seq), dtype=np.int64)
        for i, user_id in enumerate(user_ids):
            res[i] = self.get_user_seq(user_id)
        return res

    def get_item_seq(self, item_id, user_id = -1):
        '''
        get one item sequence given an item_id
        :param item_id:
        :return:
        '''
        if user_id == -1:
            if item_id in self._item_seqs:
                return self._item_seqs[item_id]
            else:
                return np.zeros(self._max_len_item_seq, dtype=np.int64)
        else:
            return self.interactions_dict[(user_id, item_id)][1]



    def get_batch_seqs(self, user_ids, item_ids, max_seq_len=100):
        if max_seq_len != -1:
            #get the shortened sequences
            return self.get_batch_seqs_topn(user_ids, item_ids, max_seq_len)
        else:
            return self.get_batch_seqs_full(user_ids, item_ids)
    def get_batch_seqs_full(self, user_ids, item_ids):
        batch_size = len(user_ids)
        user_seqs = np.zeros((batch_size, self._max_len_user_seq), dtype=np.int64)
        item_seqs = np.zeros((batch_size, self._max_len_item_seq), dtype=np.int64)
        for i, (uid, iid) in enumerate(zip(user_ids, item_ids)):
            if uid in self._user_seqs:
                user_seq = self._user_seqs[uid]
                user_seq = user_seq[user_seq != iid] #remove item iid in user seq
            else:
                user_seq = np.zeros(self._max_len_user_seq, dtype=np.int64)

            if iid in self._item_seqs:
                item_seq = self._item_seqs[iid]
                item_seq = item_seq[item_seq != uid] #remove user uid in item seq
            else:
                item_seq = np.zeros(self._max_len_item_seq, dtype=np.int64)
            user_seq_tmp = np.zeros(self._max_len_user_seq, np.int64)
            user_seq_tmp[-len(user_seq):] = user_seq
            item_seq_tmp = np.zeros(self._max_len_item_seq, dtype=np.int64)
            item_seq_tmp[-len(item_seq):] = item_seq
            user_seqs[i] = user_seq_tmp
            item_seqs[i] = item_seq_tmp
            
            
            #user_seqs.append(np.asarray(user_seq, dtype=np.int64))
            #item_seqs.append(np.asarray(item_seq, dtype=np.int64))
        return np.asarray(user_seqs, np.int64), np.asarray(item_seqs, np.int64)
    def get_batch_seqs_topn(self, user_ids, item_ids, max_seq_len=100):
        '''
        use when extracting user, item seqs with word2vec to limit sequence length.
        :param user_ids:
        :param item_ids:
        :return:
        '''
        batch_size = len(user_ids)
        assert len(user_ids) == len(item_ids)
        user_seqs = np.zeros((batch_size, max_seq_len), dtype=np.int64)
        item_seqs = np.zeros((batch_size, max_seq_len), dtype=np.int64)
        for i, (uid, iid) in enumerate(zip(user_ids, item_ids)):
            if (uid, iid) in self.interactions_dict:
                user_seq, item_seq = self.interactions_dict[(uid, iid)]
            else:
                user_seq = self.user_seqs_nopad[uid]
                user_seq = user_seq[user_seq != iid] #remove iid from user sequence
                user_seq_tmp = np.zeros(max_seq_len)
                user_seq = user_seq[-max_seq_len:]
                if len(user_seq) > 0:
                    user_seq_tmp[-len(user_seq):] = user_seq[:max_seq_len]
                user_seq = user_seq_tmp


                item_seq = self.item_seqs_nopad[iid]
                item_seq = item_seq[item_seq != uid] #remove uid from item sequence
                item_seq_tmp = np.zeros(max_seq_len)
                item_seq = item_seq[-max_seq_len:]
                if len(item_seq) > 0:
                    item_seq_tmp[-len(item_seq):] = item_seq[:max_seq_len]
                item_seq = item_seq_tmp

                self._max_cached_interactions -= 1
                if self._max_cached_interactions > 0:
                    self.interactions_dict[(uid, iid)] = (np.asarray(user_seq, dtype=np.int64),
                                                          np.asarray(item_seq, dtype=np.int64)) #adding to cache.

                # #randomly pick up a sequence
                # user_seq = self.user_seqs_nopad[uid]
                # user_seq = user_seq[user_seq != iid]
                #
                # if len(user_seq) < topn:
                #     tmp = np.zeros(topn)
                #     tmp[-len(user_seq):] = user_seq
                #     user_seq = tmp
                # else:
                #     indices = np.arange(len(user_seq))
                #     np.random.shuffle(indices)
                #     indices = indices[:topn]
                #     indices = np.sort(indices)
                #     user_seq = user_seq[indices] #randomly pick topn items
                #
                # item_seq = self.item_seqs_nopad[iid]
                # item_seq = item_seq[item_seq != uid]
                #
                # if len(item_seq) < topn:
                #     tmp = np.zeros(topn)
                #     tmp[-len(item_seq):] = item_seq
                #     item_seq = tmp
                # else:
                #     indices = np.arange(len(item_seq))
                #     np.random.shuffle(indices)
                #     indices = indices[:topn]
                #     indices = np.sort(indices)
                #     item_seq = item_seq[indices]  # randomly pick topn users

            user_seqs[i] = user_seq
            item_seqs[i] = item_seq
        return np.asarray(user_seqs, dtype=np.int64), np.asarray(item_seqs, dtype=np.int64)
    def get_batch_item_seqs(self, item_ids, user_ids):
        '''
        get batch item sequences
        :param item_ids:
        :return:
        '''
        res = np.zeros(shape=(len(item_ids), self._max_len_item_seq), dtype=np.int64)
        for i, item_id in enumerate(item_ids):
            res[i] = self.get_item_seq(item_id)
        return res

    def replace(self, seq, id):
        '''
        replace the id in the seq to padding index
        :param seq:
        :param id:
        :return:
        '''
        # pad_idx = gc.PADDING_IDX
        # non_pad_index = 0
        # for i in range(len(seq)):
        #     if seq[i] > 0:
        #         non_pad_index = i
        #         break
        # new_seq = np.zeros(len(seq))
        pass


class CoInteractions(object):
    def __init__(self, user_item_path, user_sppmi_path=None, liked_item_sppmi_path=None, disliked_item_sppmi_path=None):
        ui_row, ui_col, ui_data = self._load_data(user_item_path)
        if user_sppmi_path:
            uu_row, uu_col, uu_data = self._load_data(user_sppmi_path)
        if liked_item_sppmi_path:
            lii_row, lii_col, lii_data = self._load_data(liked_item_sppmi_path)
        if disliked_item_sppmi_path:
            dii_row, dii_col, dii_data = self._load_data(disliked_item_sppmi_path)


    def _load_data(self, path):
        data = pd.read_csv(path, sep='\t', header=None)
        row, col, data = data[0], data[1], data[2]


class SequenceInteractions(object):
    """
    Interactions encoded as a sequence matrix.

    Parameters
    ----------

    sequences: array of np.int32 of shape (num_sequences x max_sequence_length)
        The interactions sequence matrix, as produced by
        :func:`~Interactions.to_sequence`
    num_items: int, optional
        The number of distinct items in the data

    Attributes
    ----------

    sequences: array of np.int32 of shape (num_sequences x max_sequence_length)
        The interactions sequence matrix, as produced by
        :func:`~Interactions.to_sequence`
    """

    def __init__(self,
                 sequences,
                 user_ids=None, num_items=None, num_users = None, user_seqs = None):

        self.sequences = sequences
        self.user_ids = user_ids
        self.max_sequence_length = sequences.shape[1]
        self._user_seqs = user_seqs #map from user to his/her sequence

        if num_items is None:
            self.num_items = sequences.max() + 1
        else:
            self.num_items = num_items

        if num_users is not None:
             self.num_users = num_users

    def __repr__(self):

        num_sequences, sequence_length = self.sequences.shape

        return ('<Sequence interactions dataset ({num_sequences} '
                'sequences x {sequence_length} sequence length)>'
                .format(
                    num_sequences=num_sequences,
                    sequence_length=sequence_length,
                ))

    def get_user_seq(self, uid):
        return self._user_seqs[uid + 1] #add 1 because 0 is PADDING INDEX
    def get_user_seqs(self, uids):
        res = []
        for uid in uids:
            res.append(self.get_user_seq(uid))
        return res
