import MemNet as memnet
import pytorch_utils as my_utils
import time
import data_loader2 as data_loader
import os
from model_tmr import TMR
import argparse
import multiprocessing
import global_constants as gc

cpus_count = multiprocessing.cpu_count()

parser = argparse.ArgumentParser("Description: Running recommendation baselines")
parser.add_argument('--saved_path', default='chk_points', type=str)
parser.add_argument('--load_best_chkpoint', default=0, type=int, help='loading the best checking point from previous run? (yes/no)')

parser.add_argument('--path', default='data', help='Input data path', type=str)
parser.add_argument('--dataset', default='amazon-automotive',
                    help='Dataset types: ml1m, ml100k, amazon-automotive, amazon-videogames, amazon-toysandgames, amazon-officeproducts', type=str) #ml1m




parser.add_argument('--epochs', default=100, help='Number of epochs to run', type=int)
parser.add_argument('--batch_size', default=256, help='Batch size', type=int)
parser.add_argument('--num_factors', default=128, help='number of latent factors', type=int)
parser.add_argument('--n_hops', default=2, help='number of hops', type=int)
parser.add_argument('--reg', nargs='?', default='0.001', help ='Regularization for users and item embeddings', type=str) #update reg to 0.01 for ml100k
parser.add_argument('--num_neg', default=1, type=int, help='Number of negative instances for each positive sample')
parser.add_argument('--lr', default=0.001, type=float, help = 'Learning rate') #0.001 0.01 works well for amazon dataset
parser.add_argument('--loss_type', nargs='?', default='hinge',
                        help='Specify a loss function: bce, pointwise, bpr, hinge, adaptive_hinge')
parser.add_argument('--distance_metric', default='l2', help='Selecting the distance metric (l2, l1)', type=str)
parser.add_argument('--max_seq_len', type=int, default=5, help='maximum number of users/items to represents for a item/user')
parser.add_argument('--dropout', default=0.5, type=float, help='dropout probability for dropout layer')
parser.add_argument('--act_func', default='tanh', type=str,
                    help='activation function [none, relu, tanh], '
                         'use when combing target user u, target item j and consumed item i')

parser.add_argument('--gate_tying', default='gate_global', type=str, help='gate weights tying [gate_global, gate_hop_specific]')

parser.add_argument('--topk', type=int, default=10, help='evaluation top K such as: NDCG@K, HITS@K')



parser.add_argument('--optimizer', nargs='?', default='adam',
                        help='Specify an optimizer: adagrad, adam, rmsprop, sgd')
parser.add_argument('--model', default='dmr', help='Selecting the model type [tmr, dmr, gmmf], dmr= tmr + gmmf', type=str) # dmr: deep metric memory recommender

# parser.add_argument('--layers', nargs='?', default='[64,32,16,8]', help ='Regularization for users and item embeddings', type=str)

parser.add_argument('--verbose', type=int, default=1,
                        help='Show performance per X iterations')
parser.add_argument('--out', type=int, default=1,
                        help='Whether to save the trained model.')

parser.add_argument('--cuda', type=int, default=0,
                        help='using cuda or not')

parser.add_argument('--seed', type=int, default=98765,
                        help='random seed')

# parser.add_argument('--is_test', type=int, default=0,
#                         help='is testing (for fast checking whether the program is running or not')
parser.add_argument('--decay_step', type=int, default=20, help='how many steps to decay the learning rate')
parser.add_argument('--decay_weight', type=float, default=0.5, help ='percent of decaying')

parser.add_argument('--debug', default=0, type=int, help ='debugging mode, data is shortened for observation')



args = parser.parse_args()
# args.layers = eval(args.layers)
args.reg = eval(args.reg) #can be reg for users, and reg for items, but set to one value for simplification



#save to global constant
gc.BATCH_SIZE = args.batch_size
gc.DEBUG = bool(args.debug)
gc.SEED = args.seed

if gc.DEBUG: args.epochs=2
#reuse from neural collaborative filtering
def load_rating_file_as_list(filename):
    ratingList = []
    with open(filename, "r") as f:
        line = f.readline()
        while line != None and line != "":
            arr = line.split("\t")
            user, item = int(arr[0]), int(arr[1])
            ratingList.append([user, item])
            line = f.readline()
    return ratingList

#reuse from neural collaborative filtering
def load_negative_file(filename):
    negativeList = []
    with open(filename, "r") as f:
        line = f.readline()
        while line != None and line != "":
            arr = line.split("\t")
            negatives = []
            for x in arr[1: ]:
                negatives.append(int(x))
            uid, iid = arr[0].replace('(','').replace(')','').split(',')
            negativeList.append(negatives)
            #for j in range(100):
            #    negatives.append(int(iid))
            line = f.readline()
    return negativeList

train_file = os.path.join(args.path, args.dataset, '%s.train.rating'%args.dataset )
vad_file = os.path.join(args.path, args.dataset, '%s.vad.rating'%args.dataset )
vad_neg_file = os.path.join(args.path, args.dataset, '%s.vad.negative'%args.dataset )
test_file = os.path.join(args.path, args.dataset, '%s.test.rating'%args.dataset )
test_neg_file = os.path.join(args.path, args.dataset, '%s.test.negative'%args.dataset )

vadRatings = load_rating_file_as_list(vad_file)
vadNegatives = load_negative_file(vad_neg_file)
testRatings = load_rating_file_as_list(test_file)
testNegatives = load_negative_file(test_neg_file)

print args


rec_model = TMR(loss=args.loss_type, #'pointwise, bpr, hinge, adaptive_hinge'
                n_factors = args.num_factors,
                n_iter = args.epochs,
                batch_size = args.batch_size,
                reg=args.reg,    # L2 regularization
                lr = args.lr, # learning_rate
                decay_step = args.decay_step, #step to decay the learning rate
                decay_weight = args.decay_weight, #percentage to decay the learning rat.
                optimizer_func = None,
                use_cuda = args.cuda,
                random_state = None,
                num_neg_samples = args.num_neg, #number of negative samples for each positive sample.
                dropout=args.dropout,
                n_hops=args.n_hops,
                distance_metric = args.distance_metric,
                activation_func = args.act_func,
                gate_tying = args.gate_tying,
                model = args.model)


MAX_SEQ_LEN = args.max_seq_len
gc.MAX_SEQ_LEN = MAX_SEQ_LEN
load_shortened_seqs = True
print 'Debug mode:',gc.DEBUG
if gc.DEBUG:
    load_shortened_seqs = False

t0 = time.time()
t1 = time.time()
print 'parsing data'
train_iteractions = data_loader.load_data(train_file, dataset=args.dataset)
t2 = time.time()
print 'loading data time: %d (seconds)'%(t2-t1)

print 'building the model'

try:

    rec_model.fit(train_iteractions,
                      verbose=True, topN=10,
                      vadRatings = vadRatings, vadNegatives = vadNegatives,
                      testRatings=testRatings, testNegatives=testNegatives,
                      max_seq_len=MAX_SEQ_LEN, args=args)

except KeyboardInterrupt:
    print 'Exiting from training early'

t10 = time.time()
print 'Total running time: %d (seconds)'%(t10-t0)
