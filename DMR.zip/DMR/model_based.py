import glob
import os
import torch
import global_constants as gc
class ModelBased(object):
    def __init__(self):
        self._net = None
        self._optimizer = None

    def _get_model_name(self, args):
        return str(args.model)
    def _make_model_desc(self, args, model = ''):
        # model_desc = '%s_'%args.model #gmmf, tmr, or dmr
        model_desc = 'nfactors_%d' % args.num_factors
        model_desc += '_metric_%s' % args.distance_metric
        model_desc += '_reg_%s' % str(args.reg)
        model_name = args.model if model == '' else model
        if model_name == 'gmmf':
            return model_desc
        else:
            model_desc += '_num-hops_%d' % args.n_hops
            model_desc += '_%s'%args.gate_tying
            model_desc += '_seq%d' % args.max_seq_len
            model_desc += '_act_%s'% str(args.act_func)
            return model_desc

    def save_checkpoint(self, args, best_hit, best_ndcg, epoch):
        model_state_dict = self._net.state_dict()
        checkpoint = {
            'model': model_state_dict,
            'optimizer': self._optimizer.state_dict(),
            'settings': args,
            'best_hits': best_hit, #best validation/development hit
            'best_ndcg': best_ndcg, #best validation/development ndcg
            'epoch': epoch}

        model_name = '%s_%s_%s_hits_%.3f_ndcg_%.3f.chkpt' % (args.dataset,
                                                             args.model,
                                                             self._make_model_desc(args),
                                                             best_hit, best_ndcg)
        model_path = os.path.join(args.saved_path, model_name)
        torch.save(checkpoint, model_path)


    def load_checkpoint(self, args):

        if args.model in ['tmr', 'gmmf']:
            best_hits = 0.0
            best_ndcg = 0.0
            best_saved_file = ''

            # if len(os.listdir(args.saved_path)) > 0:
                # for fname in os.listdir(os.path.join(args.saved_path, '*%s*.chkpt'%args.conv_short_desc)): #must match model architecture
                # for fname in os.listdir(args.saved_path):
            saved_file_pattern = '%s_%s_%s*'%(args.dataset, args.model, self._make_model_desc(args))
            for filepath in glob.glob(os.path.join(args.saved_path,saved_file_pattern)):
                # filepath = os.path.join(args.saved_path, fname)
                if os.path.isfile(filepath):
                    print("=> loading checkpoint '{}'".format(filepath))
                    checkpoint = torch.load(filepath)
                    hits = float(checkpoint['best_hits'])
                    ndcg = float(checkpoint['best_ndcg'])
                    if hits > best_hits or (hits == best_hits and ndcg > best_ndcg):
                    # if ndcg > best_ndcg or (ndcg == best_ndcg and hits > best_hits):
                        best_saved_file=filepath
                        best_hits = hits
                        best_ndcg = ndcg
            if best_saved_file != '':
                checkpoint = torch.load(best_saved_file)
                self._net.load_state_dict(checkpoint['model'])
                self._optimizer.load_state_dict(checkpoint['optimizer'])
                print("=> loaded checkpoint '{}' (epoch {})"
                              .format(best_saved_file, checkpoint['epoch']))

            return (best_hits, best_ndcg)

        else:
            #dmr : Deep Metric memory Recommender
            # print 'here'
            #load best gmmf checkpoint
            best_gmmf_file = ''
            best_gmmf_hits, best_gmmf_ndcgs = 0,0
            gmmf_files_pattern = '%s_gmmf_%s*'%(args.dataset, self._make_model_desc(args, 'gmmf'))
            # print gmmf_files_pattern
            for filepath in glob.glob(os.path.join(args.saved_path, gmmf_files_pattern)):
                print filepath
                if os.path.isfile(filepath):
                    print("=> loading checkpoint '{}'".format(filepath))
                    checkpoint = torch.load(filepath)
                    hits = float(checkpoint['best_hits'])
                    ndcg = float(checkpoint['best_ndcg'])
                    if hits > best_gmmf_hits or (hits == best_gmmf_hits and ndcg > best_gmmf_ndcgs):
                    # if ndcg > best_gmmf_ndcgs or (ndcg == best_gmmf_ndcgs and hits > best_gmmf_hits):
                        best_gmmf_file=filepath
                        best_gmmf_hits = hits
                        best_gmmf_ndcgs = ndcg

            #load best tmr checkpoint
            best_tmr_file = ''
            best_tmr_hits, best_tmr_ndcgs = 0, 0
            tmr_files_pattern = '%s_tmr_%s*' % (args.dataset, self._make_model_desc(args, 'tmr'))
            for filepath in glob.glob(os.path.join(args.saved_path, tmr_files_pattern)):
                if os.path.isfile(filepath):
                    print("=> loading checkpoint '{}'".format(filepath))
                    checkpoint = torch.load(filepath)
                    hits = float(checkpoint['best_hits'])
                    ndcg = float(checkpoint['best_ndcg'])
                    if hits > best_tmr_hits or (hits == best_tmr_hits and ndcg > best_tmr_ndcgs):
                    # if ndcg > best_tmr_ndcgs or (ndcg == best_tmr_ndcgs and hits > best_tmr_hits):
                        best_tmr_file = filepath
                        best_tmr_hits = hits
                        best_tmr_ndcgs = ndcg


            #now loading best checkpoints from gmmf and tmr for dmr:
            if best_gmmf_file != '':
                checkpoint = torch.load(best_gmmf_file)
                self._net._gmmf.load_state_dict(checkpoint['model'])
                # self._optimizer.load_state_dict(checkpoint['optimizer'])
                print("=> loaded checkpoint '{}' (epoch {})"
                                .format(best_gmmf_file, checkpoint['epoch']))
              
                # no train the tmr and gmmf?
                for params in self._net._gmmf.parameters():
                    params.requires_grad = False

            if best_tmr_file != '':
                checkpoint = torch.load(best_tmr_file)
                self._net._memnet.load_state_dict(checkpoint['model'])
                print("=> loaded checkpoint '{}' (epoch {})"
                                 .format(best_tmr_file, checkpoint['epoch']))
                #no train the tmr and gmmf?
                for params in self._net._memnet.parameters():
                    params.requires_grad = False
            return 0,0




