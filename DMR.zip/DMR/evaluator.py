import math
import numpy as np
import heapq
import bottleneck as bn
import global_constants as gc
#leave one out evaluation
def evaluate(model, testRatings, testNegatives, K):


    hits, ndcgs = [], []
    i = 0
    for idx in xrange(len(testRatings)):
        i+=1
        (hr, ndcg) = eval_one_rating(model, testRatings, testNegatives, K, idx)
        hits.append(hr)
        ndcgs.append(ndcg)
        if gc.DEBUG:
           if i >= 10:break# break # debug
    #print 'debug mode: ',gc.DEBUG, '#interactions: ',len(hits)
    return np.nanmean(hits), np.nanmean(ndcgs)

def eval_one_rating(model, testRatings, testNegatives, K, idx):
    '''begin_at_0: item_id and user_id begins at 0 or not. Since 0 is padding --> need to add 1:'''
    rating = testRatings[idx]
    items = testNegatives[idx][:]
    uid, iid = rating[0], rating[1]
    items.append(iid)

    users = np.full(len(items), uid, dtype=np.int64)
    items = np.asarray(items)


    # print len(items)
    predictions = model.predict(users, items)

    # for i in xrange(len(items)):
    #     item = items[i]
    #     map_item_score[item] = predictions[i]
    #
    #
    # # Evaluate top rank list
    # ranklist = heapq.nlargest(K, map_item_score, key=map_item_score.get)

    indices = np.argsort(-predictions)[:K] #indices of items with highest scores
    ranklist = items[indices]



    hr = getHitRatio(ranklist, iid)
    ndcg = getNDCG(ranklist, iid)
    # if uid < 5:
    #
    #     print ('length neg: {} , target : {}, predict: {} --> hit: {}, ndcg: {} '.format(len(items), iid, ranklist, hr, ndcg))

    return (hr, ndcg)

def getHitRatio(ranklist, gtItem):
    for item in ranklist:
        if item == gtItem:
            return 1
    return 0

def getNDCG(ranklist, gtItem):
    for i in xrange(len(ranklist)):
        item = ranklist[i]
        if item == gtItem:
            return math.log(2) / math.log(i+2)
    return 0
