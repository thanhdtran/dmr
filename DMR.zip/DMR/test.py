import numpy as np
import torch
from torch.autograd import Variable
import pytorch_utils as my_utils

# a = []
# for i in range(5):
#     n = np.random.randint(2, 10, 1)[0]
#     b = np.random.rand(n)
#     a.append(b)
# a = np.asarray(a)
# print a
# print a.shape
# print my_utils.numpy2tensor(a)


# a = torch.rand((2, 6))
# a = Variable(a)
# print (a)
# print a.view(-1, 3)

batch_size = 6
n_users = 3
n_items = 7
users = [1,1,1,2,2,2]
items = [1,2,3,4,5,6]
seqs = [[0,0,0],
        [1,2,3],
        [0,1,2],
        [0,1,3],
        [0,2,3],
        [0,2,3]]
import MemNet as mn
users = Variable(my_utils.numpy2tensor(np.asarray(users)))
items = Variable(my_utils.numpy2tensor(np.asarray(items)))
seqs = Variable(my_utils.numpy2tensor(np.asarray(seqs)))
print seqs

memnet = mn.CombinedModel(n_users, n_items, 5, 3, None)
print memnet(seqs, users, items)
print memnet._get_l2_loss()