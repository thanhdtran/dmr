import pandas as pd
import os
import numpy as np
import argparse
import global_constants as gc

parser = argparse.ArgumentParser("Description: Running preprocess")
parser.add_argument('--path', default='data', type=str, help='path to the data')
parser.add_argument('--dataset', default='amazon-automotive', type=str, help='ml1m, ml100k, amazon-automotive, amazon-videogames, amazon-toysandgames, amazon-officeproducts')
parser.add_argument('--k_cores', default=5, type=int, help='filter users with at least k items, filter items with at least k users')
args = parser.parse_args()


def get_count(df, id):
    count_groupbyid = df[[id]].groupby(id, as_index=False)
    count = count_groupbyid.size()
    # print count.index[count >= 2]
    return count



np.random.seed(gc.SEED)

for dataset in os.listdir(args.path):
    data_file = os.path.join(args.path, dataset, '%s.train.rating' % dataset)
    if os.path.exists(data_file):
        df = pd.read_csv(data_file, sep='\t', header=None)
        print '\n'
        print 'working on dataset: ', dataset
        usercount, projectcount = get_count(df, 0), get_count(df, 1)
        n_users = len(df[0].unique())
        n_items = len(df[1].unique())
        n_interactions = df.shape[0]
        density = n_interactions *1.0/ (n_users * n_items)
        print '#users: %d, #items: %d, #interactions: %d, density (percent): %.3f'%(n_users, n_items, n_interactions, density*100)
        print '#interactions/user: %.2f, min : %d, max: %d, median: %d'%(np.mean(usercount.values), np.min(usercount.values),
                                                                         np.max(usercount.values), np.median(usercount.values))
        print '#interactions/item: %.2f, min : %d, max: %d, median: %d'%(np.mean(projectcount.values), np.min(projectcount.values),
                                                                      np.max(projectcount.values), np.median(projectcount.values))

data_file = os.path.join(args.path, 'amazon-automotive', 'test.csv' )
df = pd.read_csv(data_file, sep='\t', header=None)
usercount, projectcount = get_count(df, 0), get_count(df, 1)
print '#interactions/user: %.2f, min : %d, max: %d, median: %d'%(np.mean(usercount.values), np.min(usercount.values),
                                                                 np.max(usercount.values), np.median(usercount.values))
print '#interactions/item: %.2f, min : %d, max: %d, median: %d'%(np.mean(projectcount.values), np.min(projectcount.values),
                                                                      np.max(projectcount.values), np.median(projectcount.values))